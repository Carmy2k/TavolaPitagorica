
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Tavola Pitagorica</title>
	<background="red"></background:>
	<link rel="stylesheet" href="TP.css">
</head>
<body>
<h1>Tavola Pitagorica</h1>
<table>
<?php
// Definizione della dimensione della tabella pitagorica
$dimensione = 10;


// Ciclo esterno per le righe
for ($riga = 1; $riga <= $dimensione; $riga++) {
	echo "<tr>"; // Inizio di una nuova riga

    // Ciclo interno per le colonne
    for ($colonna = 1; $colonna <= $dimensione; $colonna++) {
		$prodotto = $riga * $colonna; // Calcolo del prodotto

        echo "<td>" . $prodotto . "</td>"; // Stampa del prodotto in una cella
    }

    echo "</tr>"; // Fine della riga
}
?>
</table>
</body>
</html>